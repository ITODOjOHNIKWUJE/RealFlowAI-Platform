# RealFlow AI - MVP Documentation

## Project Overview
RealFlow AI is an AI Automation Agency platform targeting real estate businesses, small service-based entrepreneurs, and productivity-focused professionals. This MVP includes a modern website, client portal, lead capture system, and backend automation tools.

## Project Structure

```
realflow_ai/
├── frontend/               # React frontend application
│   ├── src/
│   │   ├── assets/         # Images, CSS, and other static assets
│   │   ├── components/     # Reusable UI components
│   │   ├── lib/            # Utilities and API integration
│   │   ├── pages/          # Page components
│   │   └── App.tsx         # Main application component
│   └── public/             # Public assets
└── backend/                # Flask backend application
    ├── src/
    │   ├── models/         # Database models
    │   ├── routes/         # API endpoints
    │   └── main.py         # Main entry point
    └── requirements.txt    # Python dependencies
```

## Features

### Frontend
- **Home Page**: Modern design with clear value proposition, feature showcase, testimonials, and CTAs
- **Services Page**: Detailed presentation of AI automation services with visual examples
- **Pricing Page**: Tiered pricing structure with feature comparisons and custom packages
- **Contact Page**: Lead capture form with consultation booking option
- **Client Portal**: Secure login area with project status tracking, resource downloads, and messaging
- **Learning Center**: Placeholder for future educational content

### Backend
- **Authentication**: Secure login/logout functionality for client portal
- **Lead Management**: Capture and track leads from contact forms
- **Resource Management**: Upload and share files with clients
- **Messaging System**: Two-way communication between clients and admins
- **Project Tracking**: Monitor project status and next steps

## Technology Stack
- **Frontend**: React with TypeScript, Tailwind CSS, shadcn/ui components
- **Backend**: Flask with SQLAlchemy
- **Database**: SQLite (development), can be upgraded to PostgreSQL for production
- **Authentication**: Session-based authentication with Flask-Session

## Getting Started

### Running the Frontend
```bash
cd frontend
pnpm install
pnpm run dev
```

### Running the Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate
pip install -r requirements.txt
python src/main.py
```

## Deployment
The application is ready for deployment using the following methods:

### Frontend Deployment
The React frontend can be built for production:
```bash
cd frontend
pnpm run build
```

### Backend Deployment
The Flask backend can be deployed using Gunicorn or similar WSGI server:
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 src.main:app
```

## Next Steps
1. **User Testing**: Conduct usability testing with real users
2. **Content Enhancement**: Add more testimonials, case studies, and blog content
3. **Learning Center Development**: Develop full educational modules
4. **Advanced Integrations**: Connect with additional CRM systems and tools
5. **Analytics Implementation**: Add tracking and reporting features

## Support
For any questions or issues, please contact the development team.
